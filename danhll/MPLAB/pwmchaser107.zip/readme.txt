8 Channel PWM LED Chaser for PIC 16F628A / PIC16F88

http://picprojects.org.uk

Release data 19/03/2009
Web Version 1.0.6

Unzip all files to a single directory

pwmc_main106_628.HEX is ready to program into PIC 16F628 / 16F628A
pwmc_main106_88.HEX is ready to program into PIC 16F88